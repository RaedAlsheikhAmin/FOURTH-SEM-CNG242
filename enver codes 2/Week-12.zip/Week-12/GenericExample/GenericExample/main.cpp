#include"Header.h"

int main()
{
	buffer<char, 10> b1;
	buffer<double, 20> b2;

	return 0;
}