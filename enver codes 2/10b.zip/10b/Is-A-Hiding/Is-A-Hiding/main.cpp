#include"Header.h"

int main()
{
	B b1(10, 20);
	//b1.printer();

	C c1(10, 100, 1000);
	c1.printer();

	return 0;
}