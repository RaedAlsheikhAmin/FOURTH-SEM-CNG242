#include"Header.h"

void myclass::Show()
{
	cout << "This is a static function" << endl;
}