#include<iostream>
using namespace std;

template<class alpha,int i>
class buffer
{
private:
	alpha container[i];
	int size;
public:

};
