#include"Header.h"

int main()
{
	C cobj(1, 2, 3);
	cobj.printer();

	return 0;
}