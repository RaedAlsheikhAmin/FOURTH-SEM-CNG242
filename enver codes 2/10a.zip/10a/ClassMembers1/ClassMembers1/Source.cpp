#include"Header.h"

int main()
{
	A a1(1), a2(2), a3(3);
	A a4(10);
	cout << "The total number of objects:" << A::getnumberofclassA() << endl;

	return 0;
}