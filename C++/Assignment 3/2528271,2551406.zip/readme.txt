compiler: Clion-C+17

There are not that much changes in the game, but I am printing extra information.
I deleted applybonus function because I coudln't deal with removing the buff after getting it(lack of time), so I felt unfair toward it.

This code is implemented and tested on Windows 10.

There are no bugs, but I commented something in the code I couldn't find solution for it.

20th of June (10am -> 5pm)

the implementation went smooth, but I was lazy and I delayed that project until the last second, otherwise it would be perfectly done.

I may not have time to seperate the files, you may ignore this if you see the files seperated into cpp and header file.
Best Wishes.