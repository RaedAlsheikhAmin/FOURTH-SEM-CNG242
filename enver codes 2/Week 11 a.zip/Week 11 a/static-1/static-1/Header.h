#include<iostream>

using namespace std;

class myclass
{
public:
	static void Show();
};