#include"Header.h"

int main()
{
	//myclass m1;
	//m1.Show();

	myclass::Show();


	return 0;
}