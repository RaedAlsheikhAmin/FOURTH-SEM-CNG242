#include"Header.h"

int main()
{
	C c1(1,2,3);
	c1.printC();

	return 0;
}