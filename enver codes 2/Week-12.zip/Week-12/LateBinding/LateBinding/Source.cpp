#include"Header.h"

//void A::get() { cout << "get of class A" << endl; }

void B::get(){ cout << "get of class B" << endl; }