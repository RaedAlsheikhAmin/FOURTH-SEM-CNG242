#include"Header.h"

int main()
{
	//A a1; 
	B b1;
	A* ptr;
	//ptr = &a1;
	//ptr->get();

	ptr = &b1;
	ptr->get();

	return 0;
}
