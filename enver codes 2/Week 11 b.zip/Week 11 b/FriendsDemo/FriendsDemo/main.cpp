#include"Header.h"

int main()
{
	X x1(10);
	Y y1(20);
	y1.Xprinter(x1);

	return 0;
}